#!/usr/bin/env python3
from brain_games.games.brain_prime_game import brain_prime_game


def main():
    brain_prime_game()


if __name__ == "__main__":
    main()
