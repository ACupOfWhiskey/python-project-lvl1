# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games',
 'brain_games.game_engine',
 'brain_games.games',
 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc_script:main',
                     'brain-even = brain_games.scripts.brain_even_script:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd_script:main',
                     'brain-prime = '
                     'brain_games.scripts.brain_prime_script:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression_script:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'Brain games - great way to test your math skills',
    'long_description': None,
    'author': 'ACupOfWhiskey',
    'author_email': 'mia.nishida@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/ACupOfWhiskey/python-project-lvl1',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
