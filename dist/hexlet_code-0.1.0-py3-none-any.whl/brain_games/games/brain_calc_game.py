#!/usr/bin/env python3
import brain_games.game_engine.common_logic 


def brain_calc_game():
    brain_games.game_engine.common_logic.greetings_user()
    brain_games.game_engine.common_logic.asking_user_name()
    brain_games.game_engine.common_logic.brain_calc_task()
    brain_games.game_engine.common_logic.brain_calc_logic()
