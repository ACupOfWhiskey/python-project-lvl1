import random
import prompt
import math
from brain_games.games.brain_gcd import brain_gcd


def main():
    brain_gcd()

if __name__ == "__main__":
    main()